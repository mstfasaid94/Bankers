public class Customer implements Runnable {
    public static final int COUNT = 5;    // number of threads
    public static  boolean canRun = false;
    private int numofresources;     // N different resources
    private int[] maxDemand;        // maximum this thread will demand
    private int customerNum;        // customer number
    private int[] request;          // request it is making

    private java.util.Random rand;  // random number generator

    private Bank theBank;           // synchronizing object
    public Customer(int customerNum, int[] maxDemand, Bank theBank) {
        this.customerNum = customerNum;
        this.maxDemand = new int[maxDemand.length];
        this.theBank = theBank;

        System.arraycopy(maxDemand,0,this.maxDemand,0,maxDemand.length);
        numofresources = maxDemand.length;
        request = new int[numofresources];
        rand = new java.util.Random();
    }

    public void run() {
        canRun = false;

        while (canRun) {
            try {
                SleepUtilities.nap(1);

                for (int i = 0; i < numofresources; i++) {
                    request[i] = rand.nextInt(maxDemand[i] + 1);
                }
                if (theBank.requestResources(customerNum, request)) {   // if customer can proceed
                    SleepUtilities.nap();   // use and release the resources
                    theBank.releaseResources(customerNum, request);


                }
            } catch (InterruptedException ie) {
                        canRun=false;
            }
        }
        //System.out.println("all done");
    }
}
